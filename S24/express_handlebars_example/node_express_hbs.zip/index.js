const express = require("express");
const app = express();
const path = require("path");

const exphbs = require("express-handlebars");
const exp = require("constants");

const HTTP_PORT = process.env.PORT || 8080;

app.use(express.urlencoded({ extended: true }));

app.engine(".hbs", exphbs.engine({ extname: ".hbs" }));

app.set("view engine", ".hbs");

// GET route index
app.get("/", (req, res) => {
  res.render("index");
});

app.get("/about", (req, res) => {
  res.render("about");
});

app.listen(HTTP_PORT, () => {
  console.log(`server listening on: http://localhost:${HTTP_PORT}`);
});
